AngularJS-WebAPI-BookStore
==========================

This application demonstrates how to use Asp.Net web api RESTful services to send and receive data with angularJS. Apart from that you can see how angularJS is very effective in creating applications where we need to do real-time DOM manipulation.  Also this is a single page application which utilizes angular views to navigate to different pages. 

This application does not contain any kind of user management or any payment processing system as this is outside the boundary of the scope of this article, but you can implement them easily enough if you want to by modifying the existing code. 

